show databases;
use COMPANY; 
Select Essn From DEPENDENT Where Sex = "F";